﻿// CIS 200 - 01
// Program 5 - Extra Credit
// Grading ID: C8430
// Due Date: 12/5/2017
// A test application that creates 3 tree objects - one that stores ints
// one that stores doubles and one that stores strings. Then we output the
// inorder traversal for each Tree.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program5
{
    public class GenericTreeTest
    {
        static void Main(string[] args)
        {
            Random rNum = new Random();

            //tree of integer values 

            Tree<int> tree = new Tree<int>();
            int insertvalue;

            // insert the random values in the tree 
            Console.WriteLine("Inserting values: ");

            //insert 10 nodes
            for (int i=1; i<=10; i++)
            {
                insertvalue = rNum.Next(100);
                Console.WriteLine(insertvalue + " ");
                tree.InsertNode(insertvalue);
            }
            
            //show inorder traversal
            Console.WriteLine("\n\nInorder traversal");
            tree.InorderTraversal();

            //create the tree of double values

            Tree<double> treeDouble = new Tree<double>();
            double insertvalueDouble;
            Console.WriteLine("\n\nInserting values double: ");

            // loop fr inserting 10 nodes in the tree
            for (double i=8.1; i<=17.1; i++)
            {
                insertvalueDouble = (double)i;
                Console.Write(insertvalueDouble + " ");
                treeDouble.InsertNode(insertvalueDouble);
            }

            //show the inorder traversal
            Console.WriteLine("\n\nInorder traversal");
            treeDouble.InorderTraversal();

            //create the tree of strings
            Tree<string> treestring = new Tree<string>();
            string insertvaluestring;
            Console.WriteLine("\n\nInserting values string: ");

            //loop for inserting the nodes in the tree
            for (int i =1 ; i <= 10; i++)
            {
                insertvaluestring = i.ToString();
                Console.Write(insertvaluestring + " ");
                treestring.InsertNode(insertvaluestring);
            }

            //show the inorder traversal
            Console.WriteLine("\n\nInorder traversal");
            treestring.InorderTraversal();
        }
    }
}
