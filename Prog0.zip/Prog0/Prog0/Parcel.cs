﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public abstract class Parcel
    {
        private Address originAddress; // Address's origin zip code
        private Address destinationAddress; // Address's desitnation zip code

        //Pre: none
        //Post: parcel time initialized w/ the specific values for address
        public Parcel(Address originAdd, Address destAdd)
        {
            //properties for validation
            OriginAddress = originAdd;
            DestinationAddress = destAdd;
        }

        public Address OriginAddress
        {
            get
            {
                //pre: none
                //post: origin address has returned
                return originAddress;
            }
            // pre: none
            // post: origin address is set to value
            set
            {
                originAddress = value;
            }
        }

        public Address DestinationAddress
        {
            //pre: none
            //post: destination address has returned
            get
            {
                return destinationAddress;
            }
            // pre: none
            // post: destination address is set to value
            set
            {
                destinationAddress = value;
            }
        }
        public abstract decimal CalcCost(); // abstract method to return the giving cost

        // return a string in currency format as required
        public override string ToString() => $"{DestinationAddress}\n {OriginAddress}\n {CalcCost()} ";
        
    }

}


















