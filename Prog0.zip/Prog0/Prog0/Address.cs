﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public class Address
    {
        //backing fields
        private string _name;          //Name
        private string _addressLine1; //Address Line 1
        private string _addressLine2; //Address Line 2
        private string _city;        //  City
        private string _state;      // State 
        private int _zip;          // Zip

        // Validation values
        public const int MIN_ZIP = 00000; // Minimum zip code value
        public const int MAX_ZIP = 99999; // Maximum zip code value

        // Constructor to espcifie the names as required 
        public Address(string name, string addressLine1, string addressLine2, string city,
            string state, int zip)
        {
            // Set properties
            Name = name;
            AddressLine1 = addressLine1;
            AddressLine2 = addressLine2;
            City = city;
            State = state;
            Zip = zip;
        }
        // overloaded constructor to set an empty string in case the address don't have address line 2.
        public Address(string name, string addressLine1, string city, string state, int zip)
        {
            // properties to ensure validation 
            Name = name;
            AddressLine1 = addressLine1;
            City = city;
            State = state;
            Zip = zip;
        }
        public string Name
        {
            //PreCondition : none
            //Postcondition: the name has been returned
            get
            {
                return _name;
            }
            //Pre : none
            //Post: the name has been set to the value
            set
            {
                _name = value;
            }
        }

        public string AddressLine1
        {
            //Pre : none
            //Post: the address line 1 has been returned
            get
            {
                return _addressLine1;
            }
            //Pre: none
            //Post: the address line 1 has been set to the value
            set
            {
                _addressLine1 = value;
            }


        }

        public string AddressLine2
        {
            //Pre : none
            //Post: the address line 2 has been returned
            get
            {
                return _addressLine2;
            }
            //Pre: none
            //Post: the address line 2 has been set to the value
            set
            {
                _addressLine2 = value;
            }

        }
        public string City
        {
            //Pre : none
            //Post: the city has been returned
            get
            {
                return _city;
            }
            //Pre: none
            //Post: the city has been set to the value
            set
            {
                _city = value;
            }
        }
        public string State
        {
            //Pre : none
            //Post: the state has been returned
            get
            {
                return _state;
            }
            //Pre: none
            //Post: the state has been set to the value
            set
            {
                _state = value;
            }
        }
        public int Zip
        {
            //Pre : none
            //Post: the zip has been returned
            get
            {
                return _zip;
            }
            //Pre: none
            //Post: the zip has been set to the value
            set
            {
                _zip = value;
            }
        }
        // return a string formated as required. 
        public override string ToString() => $"\n{AddressLine1}{AddressLine2}\n{City}\n{State} {Zip:D5}";
    }




}
