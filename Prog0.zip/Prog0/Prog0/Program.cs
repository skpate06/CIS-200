﻿// Grading ID: C8430
// Due Date: Sep 11th
//Program 0
// CIS 200-01
// This program is designed and implemented as a simple class hierarchy for package-
// delievery services such as UPS or FedEx.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Parcel> parcel = new List<Parcel>();
            List<Address> address = new List<Address>();

            Address address1 = new Address("Avee Pate", "456 Jessica Allen Dr", "Gulf Shore", "AL", 30478);
            Address address2 = new Address("Jessica Oza", "718 Marigold Dr", "Sterling Heights", "MI", 50268);
            Address address3 = new Address("Joey Sanders", "234 Jamie Collins", "Chicago", "IL", 80304);
            Address address4 = new Address("Veronica Lewis", "23 Joy Street", "Houston", "TX", 30291);

            parcel.Add(new Letter(address1, address2, 1));
            parcel.Add(new Letter(address2, address3, 2));
            parcel.Add(new Letter(address3, address4, 3));
           
                foreach (Letter letter in parcel)
                    Console.WriteLine("{0}\n", letter);
         
        }
    }
}
