﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    class Letter : Parcel
    {
        private decimal fixedCost; // fixed cost
        // Pre: none
        //Post: the letter item has been initilized with the specific values
        public Letter(Address originadd, Address destAdd, decimal fixedCost) : base(originadd, destAdd)
        {
            FixedCost = fixedCost;
        }
        public decimal FixedCost
        {
            //Pre: none
            // Post: fixed cost is returned
            get
            {
                return fixedCost;
            }
            // pre: none
            //post: fixed cost is set to value
            set
            {
                fixedCost = value;
            }
        }
        // pre: none
        //post: CalcCost is set to fixed cost
        public override decimal CalcCost() // override to return fixed cost in the constructor
        {
            return FixedCost;
        }
        public override string ToString() => $"{DestinationAddress}\n {OriginAddress}\n {FixedCost:C}";
        
        }
    }
    
