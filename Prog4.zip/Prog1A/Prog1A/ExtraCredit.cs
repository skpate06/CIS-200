﻿// Grading ID: C8430
// Due Date: 11/27/2017
// Program 4
// CIS 200-01
// Extra Credit class to create (and test) a new sort order that will first order by Parcel type (ascending) 
// and then cost (descending) within each grouping. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog4
{
    class ExtraCredit : IComparer<Parcel>
    {
        //Pre: None
        //Post: Sort orders first by ascending and than by descending
        //                When p1 < p2, method returns positive #
        //                When p1 == p2, method returns zero
        //                When p1 > p2, method returns negative #
        public int Compare(Parcel p1, Parcel p2)
        {
            //ensure correct handling of null values (in .NET, null less than anything)
            if (p1 == null && p2 == null) // both null?
                return 0; // Equal

            if (p1 == null) // only p1 is null?
                return -1; // null is less than any actual time

            if (p2 == null) // only p2 is null?
                return 1; // Any actual time is greater than null

            if (p1.GetType().ToString().CompareTo(p2.GetType().ToString()) != 0)
                return (p1.GetType().ToString()).CompareTo(p2.GetType().ToString()); 

            else return 0;
        }
    }
}
