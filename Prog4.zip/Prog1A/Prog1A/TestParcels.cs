﻿// Grading ID: C8430
// Due Date: 11/27/2017
// Program 4
// CIS 200-01
// This is a simple, console application designed to exercise the Parcel hierarchy.
// It creates several different Parcels and prints them. A List of 10 Parcel objects use all the various item types. 
// It displays the list of items in the original order then it sorts the list using the default ordering (ascending by cost). 
// It displays the list again. Than, it sorts the list using comparer to create descending by destination zip code and display the newly ordered list. 
// The test application can be a simple console application as in the attached SortingDemo.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog4
{
    class TestParcels
    {
        // Precondition:  None
        // Postcondition: Parcels have been created and displayed
        static void Main(string[] args)
        {
            // Test Data - Magic Numbers OK
            Address a1 = new Address("  John Smith  ", "   123 Any St.   ", "  Apt. 45 ",
                "  Louisville   ", "  KY   ", 40202); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.",
                "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            Address a5 = new Address("Kam Rogers", "6103 Jessica Allen Dr", "Apt. B",
                "Birmigham", "AL", 35294); //Test Address 5
            Address a6 = new Address("Susan J. Bynoe", "1115 Scenicview Drive",
                "Bellevue", "WA", 98007);
            Address a7 = new Address("Scott T. Heise", "3151 Carson Street",
                "San Diego", "CA", 92103);
            Address a8 = new Address("Mary W. Day", "1874 Central Avenue", "Jersey City"
                , "NJ", 07304);
            Address a9 = new Address("Lucien M. Luce", "1544 Circle Drive", "Houston",
                "TX", 77056);
            Address a10 = new Address("Raymond B. Kelley", "512 Ventura Drive", "Santa Clara",
                "CA", 95054);


            Letter letter1 = new Letter(a1, a2, 3.95M); // Letter test object
            Letter letter2 = new Letter(a3, a4, 4.5M);
            Letter letter3 = new Letter(a5, a6, 10.5M);
            GroundPackage gp1 = new GroundPackage(a3, a4, 14, 10, 5, 12.5); // Ground test object
            GroundPackage gp2 = new GroundPackage(a5, a6, 13, 9, 4, 11.5);
            GroundPackage gp3 = new GroundPackage(a7, a8, 12, 8, 3, 10.5);
            NextDayAirPackage ndap1 = new NextDayAirPackage(a1, a3, 24, 14, 14, 84, 6.50M); // Next Day test object
            NextDayAirPackage ndap2 = new NextDayAirPackage(a2, a4, 23, 13, 13, 83, 5.50M);
            NextDayAirPackage ndap3 = new NextDayAirPackage(a5, a6, 25, 15, 15,    
                85, 7.50M);
            TwoDayAirPackage tdap1 = new TwoDayAirPackage(a4, a1, 46.5, 39.5, 28.0, // Two Day test object
                80.5, TwoDayAirPackage.Delivery.Saver);


            List<Parcel> parcels; // List of test parcels

            parcels = new List<Parcel>(); 

            parcels.Add(letter1); // Populate list
            parcels.Add(letter2);
            parcels.Add(letter3);
            parcels.Add(gp1);
            parcels.Add(gp2);
            parcels.Add(gp3);
            parcels.Add(ndap1);
            parcels.Add(ndap2);
            parcels.Add(ndap3);
            parcels.Add(tdap1);

            Console.WriteLine("Original List:");
            Console.WriteLine("====================");
            foreach (Parcel p in parcels)
            {
                Console.WriteLine(p);
                Console.WriteLine("====================");
            }
            Pause();

            parcels.Sort(); // Uses natural order of sort
            Console.Out.WriteLine("Sorted list (natural order):");
            Console.WriteLine("====================");
            foreach (Parcel p in parcels)
            {
                Console.WriteLine(p);
                Console.WriteLine("====================");
            }
            Pause();

            parcels.Sort(new DescendZip()); // Sort uses specified comparer class
            Console.Out.WriteLine("Sorted list (descending natural order) using Comparer:");
            Console.WriteLine("====================");
            foreach (Parcel p in parcels)
            {
                Console.WriteLine(p);
                Console.WriteLine("====================");
            }
            Pause();

            parcels.Sort(new ExtraCredit()); // Sort uses specified comparer class
            Console.Out.WriteLine("Extra Credit list (by type ascending and cost descending) using Comparer:");
            Console.WriteLine("====================");
            foreach (Parcel p in parcels)
            {
                Console.WriteLine(p);
                Console.WriteLine("====================");
            }
            Pause();
        }

        // Precondition:  None
        // Postcondition: Pauses program execution until user presses Enter and
        //                then clears the screen
        public static void Pause()
        {
            Console.WriteLine("Press Enter to Continue...");
            Console.ReadLine();

            Console.Clear(); // Clear screen
        }
    }
}
