﻿// Program 1B
// CIS 200-01
// Fall 2017
// Due: 10/4/2017
// Grading ID: C8430

// This program is designed to display reports generated using LINQ. There are 9 Address objects with different zipcodes which are used as origin 
// and destination addresses with parcels. We are using LINQ to create a result variable for each report specified and labeling each in the output.
// We have used the LINQ to produce reports : by selecting all parcels and order by desti zip in descending; by selecting all parcels and order by
// cost in ascending; by selecting all Parcels and order by Parcel type (ascending) and then cost (descending); Select all AirPackage objects that 
// are heavy and order by weight (descending)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class ProgramTestParcels
    {
        // Precondition:  None
        // Postcondition: Parcels have been created and displayed
        static void Main(string[] args)
        {
            Address a1 = new Address("  John Smith  ", "   123 Any St.   ", "  Apt. 45 ", "  Louisville   ", "  KY   ", 40202);  // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.", "Beverly Hills", "CA", 90210);                                 // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321", "El Paso", "TX", 79901);                // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7", "Portland", "ME", 04101);                    // Test Address 4
            Address a5 = new Address("Avee Patel", "456 Jessica Allen Dr", "Gulf Shore", "AL", 30478);                        // Test Address 5
            Address a6 = new Address("Jessica Oza", "718 Marigold Dr", "Sterling Heights", "MI", 50268);                     // Test Adress 6
            Address a7 = new Address("Joey Sanders", "234 Jamie Collins", "Chicago", "IL", 80304);                           // Test Address 7
            Address a8 = new Address("Veronica Lewis", "23 Joy Street", "Houston", "TX", 30291);                            // Test Address 8
            Address a9 = new Address("Daniella Swift", "555 Indian Lake Springs", "LosAngeles", "CA", 91006);              // Test Address 9

            Letter letter1 = new Letter(a1, a3, 0.5M);        // Test Letter 1
            Letter letter2 = new Letter(a2, a4, 1.20M);      // Test Letter 2
            Letter letter3 = new Letter(a4, a1, 1.70M);     // Test Letter 3

            GroundPackage grndPkg1 = new GroundPackage(a1, a5, 8, 9, 6, 12.8); // ground package object
            GroundPackage grndPkg2 = new GroundPackage(a2, a8, 20, 15, 18, 50); // ground package object

            TwoDayAirPackage twoDayAirPkg1 = new TwoDayAirPackage(a3, a7, 35, 12.8, 9, 36, TwoDayAirPackage.Delivery.Saver); // two day air package
            TwoDayAirPackage twoDayAirPkg2 = new TwoDayAirPackage(a9, a6, 10.5, 6, 8, 90, TwoDayAirPackage.Delivery.Early);   // two day air package

            NextDayAirPackage nxtDayAirPkg1 = new NextDayAirPackage(a5, a8, 50, 30, 20, 90, 20); // Next day Air package
            NextDayAirPackage nxtDayAirPkg2 = new NextDayAirPackage(a3, a2, 13, 11, 8, 16, 13); //  Next day Air package


            List<Parcel> parcels = new List<Parcel>();    // List of test parcels

            parcels = new List<Parcel>();

            parcels.Add(letter1); // populate list
            parcels.Add(letter2);
            parcels.Add(letter3);
            parcels.Add(grndPkg1);
            parcels.Add(grndPkg2);
            parcels.Add(twoDayAirPkg1);
            parcels.Add(twoDayAirPkg2);
            parcels.Add(nxtDayAirPkg1);
            parcels.Add(nxtDayAirPkg2);

            Console.WriteLine("Prog 0 - List of Parcels\n");
            
            foreach (Parcel p in parcels)                   // controls using string
            {
                Console.WriteLine(p);
                Console.WriteLine("--------------------");
            }

            var destZip =                                   // order by destination zip in descending
                from p in parcels
                orderby p.DestinationAddress.Zip descending
                select p;

            Console.WriteLine("Parcels in descending order by destination Zip Code: \n");

            foreach (var p in destZip)                  // controls using string
            {
                Console.WriteLine(p);
                Console.WriteLine("--------------------");
            }

            var ascendCost =                              // order by CalcCost in ascending order
                from p in parcels
                orderby p.CalcCost()
                select p;
            Console.WriteLine("Parcels in ascending order by cost: \n");

            foreach(var p in ascendCost)                   // controls using string
            {
                Console.WriteLine(p);
                Console.WriteLine("--------------------");
            }

            var byTypeCost =                                //parcels in order by type and in descending cost
                from p in parcels
                orderby p.GetType().ToString()
                orderby p.CalcCost() descending
                select p;

            Console.WriteLine("Parcels in order by the type and descending cost\n");

            foreach(var p in byTypeCost)                                 //controls using string
            {
                Console.WriteLine(p);
                Console.WriteLine("------------------------");
            }

            var heavyAir =                                              // holds results of LINQ, order Heavy air packages in descending order
                from p in parcels
                let airPck = p as AirPackage
                where airPck != null && airPck.IsHeavy()
                orderby airPck.IsHeavy() descending
                select airPck;

            Console.WriteLine("Heavy Air Packages in descending order");

            // process each element in heavyAir
            foreach (var a in heavyAir)                                 // controls using string
            {
                Console.WriteLine(a);
                Console.WriteLine("------------------------");
            }

        }

        
    }
}
