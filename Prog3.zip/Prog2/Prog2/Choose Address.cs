﻿// CIS 200-01
// Grading ID: C8430
// Program 3
// Due Date: 11/13/2017
// This is the Form for Addresses to choose.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    [Serializable]
    public partial class Choose_Address : Form
    {
        private List<Address> addressList;

        public Choose_Address(List<Address> addresses)
        {
            InitializeComponent();
            addressList = addresses;
        }

        internal int EditAddressIndex
        {
            // Pre: None
            // Post: returns the selected index 
            get
            {
                return addrss_ComboBox.SelectedIndex;
            }

            //Pre: Input has to be greater or equal to -1
            //Post: it thorws an argument exception inputs invalid data

            set
            {
                if ((value >= -1) && (value < addressList.Count))
                    addrss_ComboBox.SelectedIndex = value;
                else
                    throw new ArgumentOutOfRangeException("EditAddressIndex", value, "Index should be valid");
            }
        }

        public int Choose_AddressIndex { get; internal set; }

        private void Choose_Address_Load(object sender, EventArgs e)
        {
            foreach (Address a in addressList)
            {
                addrss_ComboBox.Items.Add(a.Name);
            }
        }

        // Precondition:  Focus is on address ComboBox
        // Postcondition: If text is invalid, focus remains and error provider
        //                to select an address
        private void addrss_ComboBox_Validating(object sender, CancelEventArgs e)
        {
            if (addrss_ComboBox.SelectedIndex < 0)
            {
                e.Cancel = true;
                errorProvider1.SetError(addrss_ComboBox, "Please select an address");
            }

        }

        // Precondition:  Validating the address ComboBox
        // Postcondition: Error provider cleared 
        private void addrss_ComboBox_Validated (object sender, EventArgs e)
        {
            errorProvider1.SetError(addrss_ComboBox, "");
        }
        // Precondition:  User clicked on okBtn
        // Postcondition: If invalid field on dialog, keep form open and give first invalid
        //                field the focus. Else return OK and close form.
        private void ok_Button_Click(object sender, EventArgs e)
        {
            if (ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }
        // Precondition:  User pressed on cancelBtn
        // Postcondition: Form closes and sends Cancel result
        private void cancel_Button_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                this.DialogResult = DialogResult.Cancel;
        }
    }
}
