﻿namespace UPVApp
{
    partial class Choose_Address
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.chooseAddLbl = new System.Windows.Forms.Label();
            this.addrss_ComboBox = new System.Windows.Forms.ComboBox();
            this.ok_Button = new System.Windows.Forms.Button();
            this.cancel_Button = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // chooseAddLbl
            // 
            this.chooseAddLbl.AutoSize = true;
            this.chooseAddLbl.Location = new System.Drawing.Point(142, 45);
            this.chooseAddLbl.Name = "chooseAddLbl";
            this.chooseAddLbl.Size = new System.Drawing.Size(356, 32);
            this.chooseAddLbl.TabIndex = 0;
            this.chooseAddLbl.Text = "Choose an Address to edit:";
            // 
            // addrss_ComboBox
            // 
            this.addrss_ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.addrss_ComboBox.FormattingEnabled = true;
            this.addrss_ComboBox.Location = new System.Drawing.Point(148, 117);
            this.addrss_ComboBox.Name = "addrss_ComboBox";
            this.addrss_ComboBox.Size = new System.Drawing.Size(349, 39);
            this.addrss_ComboBox.TabIndex = 2;
            this.addrss_ComboBox.Validating += new System.ComponentModel.CancelEventHandler(this.addrss_ComboBox_Validating);
            this.addrss_ComboBox.Validated += new System.EventHandler(this.addrss_ComboBox_Validated);
            // 
            // ok_Button
            // 
            this.ok_Button.Location = new System.Drawing.Point(84, 239);
            this.ok_Button.Name = "ok_Button";
            this.ok_Button.Size = new System.Drawing.Size(161, 67);
            this.ok_Button.TabIndex = 3;
            this.ok_Button.Text = "Ok";
            this.ok_Button.UseVisualStyleBackColor = true;
            this.ok_Button.Click += new System.EventHandler(this.ok_Button_Click);
            // 
            // cancel_Button
            // 
            this.cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancel_Button.Location = new System.Drawing.Point(420, 239);
            this.cancel_Button.Name = "cancel_Button";
            this.cancel_Button.Size = new System.Drawing.Size(161, 67);
            this.cancel_Button.TabIndex = 4;
            this.cancel_Button.Text = "Cancel";
            this.cancel_Button.UseVisualStyleBackColor = true;
            this.cancel_Button.Click += new System.EventHandler(this.ok_Button_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Choose_Address
            // 
            this.AcceptButton = this.ok_Button;
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cancel_Button;
            this.ClientSize = new System.Drawing.Size(682, 518);
            this.Controls.Add(this.cancel_Button);
            this.Controls.Add(this.ok_Button);
            this.Controls.Add(this.addrss_ComboBox);
            this.Controls.Add(this.chooseAddLbl);
            this.Name = "Choose_Address";
            this.Text = "Choose_Address";
            this.Load += new System.EventHandler(this.Choose_Address_Load);
            this.Click += new System.EventHandler(this.ok_Button_Click);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label chooseAddLbl;
        private System.Windows.Forms.ComboBox addrss_ComboBox;
        private System.Windows.Forms.Button ok_Button;
        private System.Windows.Forms.Button cancel_Button;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}