﻿// Grading ID : C8430
// Program 2
// Due Date: Oct 23, 2017
// CIS 200-01
// This is the letter form which displays the origin address,
// destination adress and the fixed cost.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class LetterForm : Form
    {
        public LetterForm(List<Address> addresses)
        {
            InitializeComponent();

            foreach (Address a in addresses)
            {
                originAdd_Cb.Items.Add(a.Name);
                destAdd_Cb.Items.Add(a.Name);
            }
        }

        public int OrAddrs
        {
            //Pre: none
            // Post: select the origin address
            get
            {
                return originAdd_Cb.SelectedIndex;
            }


        }
        // origin address is validated
        private void originAdd_Cb_Validating(object sender, CancelEventArgs e)
        {
            if (originAdd_Cb.SelectedIndex < 0)
            {
                e.Cancel = true;

                errorProvider1.SetError(originAdd_Cb, "A state must be selected!");
            }
        }

        private void originAdd_Cb_Validating(object sender, EventArgs e)
        {
            errorProvider1.SetError(originAdd_Cb, "");
        }


        public int DestAddrs
        {
            get
            {
                return destAdd_Cb.SelectedIndex;
            }

        }
        // destination address is validated
        private void destAdd_Cb_Validating(object sender, CancelEventArgs e)
        {
            if (destAdd_Cb.SelectedIndex < 0)
            {
                e.Cancel = true;

                errorProvider1.SetError(destAdd_Cb, "A state must be selected!");
            }
        }

        private void destAdd_Cb_Validating(object sender, EventArgs e)
        {
            errorProvider1.SetError(destAdd_Cb, "");
        }


        public string FxdCost
        {
            //pre: none
            //Post: returns a fixed cost
            get
            {
                return fxCost_Tb.Text;
            }
            //pre: none
            //post: gathers the fixed cost
            set
            {
                fxCost_Tb.Text = value;
            }
        }

        private void fxCost_Tb_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(fxCost_Tb.Text))
            {
                e.Cancel = true;

                errorProvider1.SetError(fxCost_Tb, "Text Box can't be empty!");
            }
        }
        // fixed cost is validated
        private void fxCost_Tb__Validating(object sender, EventArgs e)
        {
            errorProvider1.SetError(fxCost_Tb, "");
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }


        private void cncl_Button_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                this.DialogResult = DialogResult.Cancel;
        }

    }
}

