﻿// Grading ID : C8430
// Program 2
// Due Date: Oct 23, 2017
// CIS 200-01
// This class creates the GUI for Program 2. It provides a file menu with About and Exit items,
// an insert menu with Address and Letter items, and a report menu with the list of addresses,
// and list of Parcel items. These items also has shortcuts to it.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class Prog2Form : Form
    {
        private UserParcelView upv; // The UserParcelVIew

        // Pre: None
        // Post: The form's GUI is prepared for display. A List of addresses is added
        public Prog2Form()
        {
            InitializeComponent();

            upv = new UserParcelView();

            // Test data added 
            upv.AddAddress("August Smith", "3247 Coleman Avenue", "Apt. 69", "Pala", "CA", 92059);                  // Test Address 0
            upv.AddAddress("Phillip Kayser", "2005 Kelly Drive", "Frederick", "CA", 21701);                         // Test Address 1
            upv.AddAddress("David Gates", "3986 Broadcast Drive", "Suite 321", "NC", 28206);                        // Test Address 2
            upv.AddAddress("Jill Eaton", "1084 Rhode Island Avenue", "Apt. 2", "Washington", "DC", 20016);          // Test Address 3
            upv.AddAddress("Addie Elliott", "4324 Deercove Drive", "Philadelphia", "PA", 19107);                    // Test Address 4
            upv.AddAddress("Joseph Burke", "4364 Virgil Street", "Panama City", "FL", 32405);                       // Test Address 5
            upv.AddAddress("Zelda Rocco", "3305 Desert Broom Court", "Jersey City", "NY", 07306);                   // Test Address 6
            upv.AddAddress("Marilyn Friley", "2416 Christie Way", "North Billerica", "MA", 01862);                  // Test Address 7
            upv.AddAddress("Sylvester Hayes", "1376 Sundown Lane", "Austin", "TX", 78701);                          // Test Address 8

            upv.AddLetter(upv.AddressAt(4), upv.AddressAt(5), 0.60M); // Letter 1 object
            upv.AddLetter(upv.AddressAt(8), upv.AddressAt(6), 1.35M); // Letter 2 object
            upv.AddLetter(upv.AddressAt(7), upv.AddressAt(1), 1.90M); // Letter 3 object
            
        }

        //Precondition: About is selected
        //Postcondition: About message box is displayed showing the Grading ID, Class and Section,
        //               and due date of the Program

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Grading ID: C8430\nCIS200-01\nProgram 2\nDue Date: 10/23/17", "About", MessageBoxButtons.OK);
        }

        //Precondition: Exit is selected.
        //Postcondition: Program is closed.
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        // Pre: Address is selected under Insert menu
        // post: The Address form appears where you need to enter the name, address
        //          city, state and zip.
        private void addressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddressForm addressForm = new AddressForm();
            DialogResult result;
            string name;
            string addrs1;
            string addrs2;
            string city;
            string state;
            int zip;

            result = addressForm.ShowDialog();

            if (result == DialogResult.OK)
            {
                name = addressForm.AddressName;
                addrs1 = addressForm.Address1;
                addrs2 = addressForm.Address2;
                city = addressForm.City;
                state = addressForm.State.ToString();
                zip = int.Parse(addressForm.Zip);

                upv.AddAddress(name, addrs1, addrs2, city, state, zip);

            }

        }

        // Pre: Letter is selected under insert menu
        // Post: The letter form appears where you need to add the origin address, destination address
        //          and the Fixed cost

        private void lEtterToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            LetterForm letterForm = new LetterForm(upv.AddressList);
            DialogResult result;
            Address orgAddrs;
            Address destAddrs;
            decimal cost;

            result = letterForm.ShowDialog();

            if (result == DialogResult.OK)
            {
                orgAddrs = upv.AddressList[letterForm.OrAddrs];
                destAddrs = upv.AddressList[letterForm.DestAddrs];
                cost = decimal.Parse(letterForm.FxdCost);

                upv.AddLetter(orgAddrs, destAddrs, cost);
            }    

        }
        // Pre: List address is selected under report menu
        // Post: The address are listed in the text box
        private void listAddressesToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            report_Tb.Clear();

            report_Tb.Text += string.Format("{0}{1}{1}", "List of Addresses", Environment.NewLine);

            foreach (var a in upv.AddressList)

                report_Tb.Text += string.Format("{0}{1}{1}", a, Environment.NewLine);
        }

        //Pre: List parcels is selected under report menu
        // Post: the parcels are listed in the text box
        private void listParcelsToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            report_Tb.Clear();

            report_Tb.Text += string.Format("{0}{1}{1}", "List of Parcels", Environment.NewLine);

            decimal totalCost = 0;

            foreach (var p in upv.ParcelList)
            {
                report_Tb.Text += string.Format("{0}{1}{1}{1}", p, Environment.NewLine);

                totalCost += p.CalcCost();
            }

            report_Tb.Text += string.Format("The total cost is: {0}", totalCost.ToString("c"));
        }

    }
}
