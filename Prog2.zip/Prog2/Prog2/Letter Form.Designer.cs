﻿namespace UPVApp
{
    partial class LetterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.originAddLbl = new System.Windows.Forms.Label();
            this.destAddLbl = new System.Windows.Forms.Label();
            this.fxCostLbl = new System.Windows.Forms.Label();
            this.originAdd_Cb = new System.Windows.Forms.ComboBox();
            this.destAdd_Cb = new System.Windows.Forms.ComboBox();
            this.fxCost_Tb = new System.Windows.Forms.TextBox();
            this.okButton = new System.Windows.Forms.Button();
            this.cncl_Button = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            this.SuspendLayout();
            // 
            // originAddLbl
            // 
            this.originAddLbl.AutoSize = true;
            this.originAddLbl.Location = new System.Drawing.Point(69, 42);
            this.originAddLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.originAddLbl.Name = "originAddLbl";
            this.originAddLbl.Size = new System.Drawing.Size(106, 17);
            this.originAddLbl.TabIndex = 0;
            this.originAddLbl.Text = "Origin Address:";
            // 
            // destAddLbl
            // 
            this.destAddLbl.AutoSize = true;
            this.destAddLbl.Location = new System.Drawing.Point(36, 101);
            this.destAddLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.destAddLbl.Name = "destAddLbl";
            this.destAddLbl.Size = new System.Drawing.Size(139, 17);
            this.destAddLbl.TabIndex = 1;
            this.destAddLbl.Text = "Destination Address:";
            // 
            // fxCostLbl
            // 
            this.fxCostLbl.AutoSize = true;
            this.fxCostLbl.Location = new System.Drawing.Point(96, 159);
            this.fxCostLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.fxCostLbl.Name = "fxCostLbl";
            this.fxCostLbl.Size = new System.Drawing.Size(77, 17);
            this.fxCostLbl.TabIndex = 2;
            this.fxCostLbl.Text = "Fixed Cost:";
            // 
            // originAdd_Cb
            // 
            this.originAdd_Cb.FormattingEnabled = true;
            this.originAdd_Cb.Location = new System.Drawing.Point(202, 42);
            this.originAdd_Cb.Margin = new System.Windows.Forms.Padding(2);
            this.originAdd_Cb.Name = "originAdd_Cb";
            this.originAdd_Cb.Size = new System.Drawing.Size(122, 24);
            this.originAdd_Cb.TabIndex = 3;
            this.originAdd_Cb.Validating += new System.ComponentModel.CancelEventHandler(this.originAdd_Cb_Validating);
            this.originAdd_Cb.Validated += new System.EventHandler(this.originAdd_Cb_Validating);
            // 
            // destAdd_Cb
            // 
            this.destAdd_Cb.FormattingEnabled = true;
            this.destAdd_Cb.Location = new System.Drawing.Point(202, 97);
            this.destAdd_Cb.Margin = new System.Windows.Forms.Padding(2);
            this.destAdd_Cb.Name = "destAdd_Cb";
            this.destAdd_Cb.Size = new System.Drawing.Size(122, 24);
            this.destAdd_Cb.TabIndex = 4;
            this.destAdd_Cb.Validating += new System.ComponentModel.CancelEventHandler(this.destAdd_Cb_Validating);
            this.destAdd_Cb.Validated += new System.EventHandler(this.destAdd_Cb_Validating);
            // 
            // fxCost_Tb
            // 
            this.fxCost_Tb.Location = new System.Drawing.Point(202, 157);
            this.fxCost_Tb.Margin = new System.Windows.Forms.Padding(2);
            this.fxCost_Tb.Name = "fxCost_Tb";
            this.fxCost_Tb.Size = new System.Drawing.Size(122, 22);
            this.fxCost_Tb.TabIndex = 6;
            this.fxCost_Tb.Validating += new System.ComponentModel.CancelEventHandler(this.fxCost_Tb_Validating);
            this.fxCost_Tb.Validated += new System.EventHandler(this.fxCost_Tb__Validating);
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(72, 235);
            this.okButton.Margin = new System.Windows.Forms.Padding(2);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(128, 38);
            this.okButton.TabIndex = 7;
            this.okButton.Text = "Ok";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // cncl_Button
            // 
            this.cncl_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cncl_Button.Location = new System.Drawing.Point(244, 235);
            this.cncl_Button.Margin = new System.Windows.Forms.Padding(2);
            this.cncl_Button.Name = "cncl_Button";
            this.cncl_Button.Size = new System.Drawing.Size(128, 38);
            this.cncl_Button.TabIndex = 8;
            this.cncl_Button.Text = "Cancel";
            this.cncl_Button.UseVisualStyleBackColor = true;
            this.cncl_Button.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cncl_Button_MouseDown);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // LetterForm
            // 
            this.AcceptButton = this.okButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cncl_Button;
            this.ClientSize = new System.Drawing.Size(522, 438);
            this.Controls.Add(this.cncl_Button);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.fxCost_Tb);
            this.Controls.Add(this.destAdd_Cb);
            this.Controls.Add(this.originAdd_Cb);
            this.Controls.Add(this.fxCostLbl);
            this.Controls.Add(this.destAddLbl);
            this.Controls.Add(this.originAddLbl);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "LetterForm";
            this.Text = "Letter Form";

            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label originAddLbl;
        private System.Windows.Forms.Label destAddLbl;
        private System.Windows.Forms.Label fxCostLbl;
        private System.Windows.Forms.ComboBox originAdd_Cb;
        private System.Windows.Forms.ComboBox destAdd_Cb;
        private System.Windows.Forms.TextBox fxCost_Tb;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cncl_Button;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
    }
}