﻿namespace UPVApp
{
    partial class AddressForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.nameLbl = new System.Windows.Forms.Label();
            this.addLbl = new System.Windows.Forms.Label();
            this.cityLbl = new System.Windows.Forms.Label();
            this.stateLbl = new System.Windows.Forms.Label();
            this.zipLbl = new System.Windows.Forms.Label();
            this.name_Tb = new System.Windows.Forms.TextBox();
            this.address_Tb1 = new System.Windows.Forms.TextBox();
            this.address_Tb2 = new System.Windows.Forms.TextBox();
            this.city_Tb = new System.Windows.Forms.TextBox();
            this.zip_Tb = new System.Windows.Forms.TextBox();
            this.state_Cb = new System.Windows.Forms.ComboBox();
            this.ok_Button = new System.Windows.Forms.Button();
            this.cncl_Button = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider5 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).BeginInit();
            this.SuspendLayout();
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Location = new System.Drawing.Point(64, 43);
            this.nameLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(98, 32);
            this.nameLbl.TabIndex = 0;
            this.nameLbl.Text = "Name:";
            // 
            // addLbl
            // 
            this.addLbl.AutoSize = true;
            this.addLbl.Location = new System.Drawing.Point(40, 112);
            this.addLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.addLbl.Name = "addLbl";
            this.addLbl.Size = new System.Drawing.Size(127, 32);
            this.addLbl.TabIndex = 1;
            this.addLbl.Text = "Address:";
            // 
            // cityLbl
            // 
            this.cityLbl.AutoSize = true;
            this.cityLbl.Location = new System.Drawing.Point(68, 231);
            this.cityLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.cityLbl.Name = "cityLbl";
            this.cityLbl.Size = new System.Drawing.Size(72, 32);
            this.cityLbl.TabIndex = 2;
            this.cityLbl.Text = "City:";
            // 
            // stateLbl
            // 
            this.stateLbl.AutoSize = true;
            this.stateLbl.Location = new System.Drawing.Point(64, 304);
            this.stateLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.stateLbl.Name = "stateLbl";
            this.stateLbl.Size = new System.Drawing.Size(90, 32);
            this.stateLbl.TabIndex = 3;
            this.stateLbl.Text = "State:";
            // 
            // zipLbl
            // 
            this.zipLbl.AutoSize = true;
            this.zipLbl.Location = new System.Drawing.Point(78, 374);
            this.zipLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.zipLbl.Name = "zipLbl";
            this.zipLbl.Size = new System.Drawing.Size(63, 32);
            this.zipLbl.TabIndex = 4;
            this.zipLbl.Text = "Zip:";
            // 
            // name_Tb
            // 
            this.name_Tb.Location = new System.Drawing.Point(184, 43);
            this.name_Tb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.name_Tb.Name = "name_Tb";
            this.name_Tb.Size = new System.Drawing.Size(274, 38);
            this.name_Tb.TabIndex = 5;
            // 
            // address_Tb1
            // 
            this.address_Tb1.Location = new System.Drawing.Point(184, 112);
            this.address_Tb1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.address_Tb1.Name = "address_Tb1";
            this.address_Tb1.Size = new System.Drawing.Size(344, 38);
            this.address_Tb1.TabIndex = 6;
            this.address_Tb1.Validating += new System.ComponentModel.CancelEventHandler(this.address_Tb1_Validated);
            this.address_Tb1.Validated += new System.EventHandler(this.address_Tb1_Validated);
            // 
            // address_Tb2
            // 
            this.address_Tb2.Location = new System.Drawing.Point(184, 169);
            this.address_Tb2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.address_Tb2.Name = "address_Tb2";
            this.address_Tb2.Size = new System.Drawing.Size(344, 38);
            this.address_Tb2.TabIndex = 7;
            // 
            // city_Tb
            // 
            this.city_Tb.Location = new System.Drawing.Point(184, 227);
            this.city_Tb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.city_Tb.Name = "city_Tb";
            this.city_Tb.Size = new System.Drawing.Size(246, 38);
            this.city_Tb.TabIndex = 8;
            this.city_Tb.Validating += new System.ComponentModel.CancelEventHandler(this.city_Tb_Validating);
            this.city_Tb.Validated += new System.EventHandler(this.city_Tb_Validating);
            // 
            // zip_Tb
            // 
            this.zip_Tb.Location = new System.Drawing.Point(184, 366);
            this.zip_Tb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.zip_Tb.Name = "zip_Tb";
            this.zip_Tb.Size = new System.Drawing.Size(246, 38);
            this.zip_Tb.TabIndex = 9;
            this.zip_Tb.Validating += new System.ComponentModel.CancelEventHandler(this.zip_Tb_Validating);
            this.zip_Tb.Validated += new System.EventHandler(this.zip_Tb_Validating);
            // 
            // state_Cb
            // 
            this.state_Cb.FormattingEnabled = true;
            this.state_Cb.Location = new System.Drawing.Point(184, 296);
            this.state_Cb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.state_Cb.Name = "state_Cb";
            this.state_Cb.Size = new System.Drawing.Size(246, 39);
            this.state_Cb.TabIndex = 10;
            this.state_Cb.Validating += new System.ComponentModel.CancelEventHandler(this.state_Cb_Validating);
            this.state_Cb.Validated += new System.EventHandler(this.state_Cb_Validating);
            // 
            // ok_Button
            // 
            this.ok_Button.Location = new System.Drawing.Point(228, 463);
            this.ok_Button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ok_Button.Name = "ok_Button";
            this.ok_Button.Size = new System.Drawing.Size(230, 56);
            this.ok_Button.TabIndex = 11;
            this.ok_Button.Text = "Ok";
            this.ok_Button.UseVisualStyleBackColor = true;
            this.ok_Button.Click += new System.EventHandler(this.ok_Button_Click_1);
            // 
            // cncl_Button
            // 
            this.cncl_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cncl_Button.Location = new System.Drawing.Point(524, 463);
            this.cncl_Button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cncl_Button.Name = "cncl_Button";
            this.cncl_Button.Size = new System.Drawing.Size(230, 56);
            this.cncl_Button.TabIndex = 12;
            this.cncl_Button.Text = "Cancel";
            this.cncl_Button.UseVisualStyleBackColor = true;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // errorProvider5
            // 
            this.errorProvider5.ContainerControl = this;
            // 
            // AddressForm
            // 
            this.AcceptButton = this.ok_Button;
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cncl_Button;
            this.ClientSize = new System.Drawing.Size(972, 591);
            this.Controls.Add(this.cncl_Button);
            this.Controls.Add(this.ok_Button);
            this.Controls.Add(this.state_Cb);
            this.Controls.Add(this.zip_Tb);
            this.Controls.Add(this.city_Tb);
            this.Controls.Add(this.address_Tb2);
            this.Controls.Add(this.address_Tb1);
            this.Controls.Add(this.name_Tb);
            this.Controls.Add(this.zipLbl);
            this.Controls.Add(this.stateLbl);
            this.Controls.Add(this.cityLbl);
            this.Controls.Add(this.addLbl);
            this.Controls.Add(this.nameLbl);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "AddressForm";
            this.Text = "Address Form";
            this.Load += new System.EventHandler(this.AddressForm_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label addLbl;
        private System.Windows.Forms.Label cityLbl;
        private System.Windows.Forms.Label stateLbl;
        private System.Windows.Forms.Label zipLbl;
        private System.Windows.Forms.TextBox name_Tb;
        private System.Windows.Forms.TextBox address_Tb1;
        private System.Windows.Forms.TextBox address_Tb2;
        private System.Windows.Forms.TextBox city_Tb;
        private System.Windows.Forms.TextBox zip_Tb;
        private System.Windows.Forms.ComboBox state_Cb;
        private System.Windows.Forms.Button ok_Button;
        private System.Windows.Forms.Button cncl_Button;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private System.Windows.Forms.ErrorProvider errorProvider5;
    }
}