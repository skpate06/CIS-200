﻿// Grading ID : C8430
// Program 2
// Due Date: Oct 23, 2017
// CIS 200-01
// This is the address class which the name of the person,
// address, city, state and zip are listed

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class AddressForm : Form
    {
        
        public const int MIN_ZIP = 0;     // Minimum ZipCode value
        public const int MAX_ZIP = 99999; // Maximum ZipCode value

        public AddressForm()

        {
            InitializeComponent();
        }
        
        public string AddressName
        {
            // Pre: None
            // Post: returns the name on the address
            get
            {
                return name_Tb.Text;
            }
            // pre:none
            // post: gathers the name on the address
            set
            {
                name_Tb.Text = value;
            }
        }
        // name text box validation
        private void name_Tb_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(name_Tb.Text))
            {
                e.Cancel = true;

                errorProvider1.SetError(name_Tb, "The Text Box cannot be empty!");
            }
        }

        private void name_Tb_Validating(object sender, EventArgs e)
        {
            errorProvider1.SetError(name_Tb, "");
        }

        public string Address1
        {
            //pre: none
            // post: returns the adrress 
            get
            {
                return address_Tb1.Text;
            }
            //pre: none
            //post: gathers the address
            set
            {
                address_Tb1.Text = value;
            }
        }

        private void address_Tb1_Validated(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(name_Tb.Text))
            {
                e.Cancel = true;

                errorProvider1.SetError(name_Tb, "The Text Box cannot be empty!");
            }
        }

        private void address_Tb1_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(address_Tb1, "");
        }

        public string Address2
        {
            //pre: none
            // post: returns the address line 2
            get
            {
                return address_Tb2.Text;
            }
            //pre: none
            // post: gathers the address on line 2
            set
            {
                address_Tb2.Text = value;
            }
        }

        public string City
        {
            //pre: none
            //post: returns the city name
            get
            {
                return city_Tb.Text;
            }
            //pre: none
            //POst: gathers the name of the city
            set
            {
                city_Tb.Text = value;
            }
        }

        // city text box validation
        private void city_Tb_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(city_Tb.Text))
            {
                e.Cancel = true;

                errorProvider1.SetError(city_Tb, "The Text Box cannot be empty!");
            }
        }

        private void city_Tb_Validating(object sender, EventArgs e)
        {
            errorProvider1.SetError(city_Tb, "");
        }

        // list of states
        private void AddressForm_Load_1(object sender, EventArgs e)
        {
            state_Cb.Items.Add("KY");
            state_Cb.Items.Add("CA");
            state_Cb.Items.Add("NC");
            state_Cb.Items.Add("MI");
            state_Cb.Items.Add("NJ");
            state_Cb.Items.Add("WA");
        }
        

        public int State
        {
            // pre: none
            //post: select a state within the options
            get
            {
                return state_Cb.SelectedIndex;
            }

        }

        private void state_Cb_Validating(object sender, CancelEventArgs e)
        {
            if (state_Cb.SelectedIndex < 0)
            {
                e.Cancel = true;

                errorProvider1.SetError(state_Cb, "A state must be selected!");
            }
        }
        // state combobox validation
        private void state_Cb_Validating(object sender, EventArgs e)
        {
            errorProvider1.SetError(state_Cb, "");
        }

        // Pre: None
        // Post: Reuturns zip code
        public string Zip
        {
            get
            {
                return zip_Tb.Text;
            }
            //Pre: zip code should be greater than 00000 and less than 99999
            // Post: gathers zip code
            set
            {
                zip_Tb.Text = value;
            }
        }
        // zip text box validation
        private void zip_Tb_Validating(object sender, CancelEventArgs e)
        {
            int zip;

            if (!int.TryParse(zip_Tb.Text, out zip) && (zip > 00000 && zip < 9999))
            {
                e.Cancel = true;

                errorProvider1.SetError(zip_Tb, "Enter a zip code between 00000 and 99999!");
            }
        }

        private void zip_Tb_Validating(object sender, EventArgs e)
        {
            errorProvider1.SetError(zip_Tb, "");
        }

        // when the cancel button is clicked
        private void cncl_Button_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                this.DialogResult = DialogResult.Cancel;
        }

        //when the ok button is clicked
        private void ok_Button_Click_1(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }
    }
}

